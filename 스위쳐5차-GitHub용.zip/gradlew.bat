@ECHO OFF
IF "%OS%"=="Windows_NT" SETLOCAL
gradle %*
